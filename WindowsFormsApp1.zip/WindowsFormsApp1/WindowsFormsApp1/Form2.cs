﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Windows.Forms;
using System.IO;

namespace WindowsFormsApp1
{
    public partial class Form2 : Form
    {
        string path = @"Data Source = DESKTOP-926II82\SQLEXPRESS; Initial Catalog= std_info; Integrated Security = true";

        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }


        private void button6_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(path);
            int gr = Convert.ToInt32(gr_no.Text);
            int contact = Convert.ToInt32(phone.Text);

            SqlCommand cmd = new SqlCommand("INSERT INTO STD_INFO (GR_NO, NAME, F_NAME, CITY, COUNTRY, DOB, GROUPP,  PHONE, EMAIL, ADRESS, PICTURE) VALUES('" + gr + "', '" + name.Text + "', '" + fname.Text + "', '" + city.Text + "', '" + dob.Text + "', '" + country.Text + "', '" + group.Text + "','" + contact + "', '" + email.Text + "', '" + adress.Text + "', '" +image + "')", conn);
            conn.Open();


            cmd.ExecuteNonQuery();
            MessageBox.Show("DATA INSERTED");
            conn.Close();

        }
        string photopath;
        byte[] binaryphoto;


        private void button8_Click_1(object sender, EventArgs e)
        {
            

            OpenFileDialog file = new OpenFileDialog();
            file.Filter = "Jpegs|*.Jpegs|png|*.png|GIf|*.Gif|jpg|*.jpg|Bitmaps|*.Bitmaps";
            file.Title = "Please select an image";
            if (file.ShowDialog() == DialogResult.OK)
            {
                image.Image = new Bitmap(file.OpenFile());
                photopath = file.FileName;
                FileStream fs = new FileStream(photopath, FileMode.Open, FileAccess.Read);
                BinaryReader br = new BinaryReader(fs);
                binaryphoto=br.ReadBytes((int)fs.Length);
                fs.Close();
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            gr_no.Text = "";
            name.Text = "";
            fname.Text = "";
            city.Text = "";
            country.Text = "";
            dob.Text = "";
            group.Text = "";
            name.Text = "";
            phone.Text = "";
            email.Text = "";
            adress.Text = "";
            image.Text = "";
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp1
{
    public partial class Form8 : Form
    {
        string conn_str = @"Data Source = DESKTOP-926II82\SQLEXPRESS; Initial Catalog= std_info; Integrated Security = true";
        public Form8()
        {
            InitializeComponent();
        }

        private void Form8_Load(object sender, EventArgs e)
        {
            DataSelect();
        }
        public void DataSelect()
        {
            SqlConnection conn = new SqlConnection(conn_str);
            SqlCommand cmd = new SqlCommand("SELECT GR_NO, NAME, F_NAME,EMAIL,GROUPP, TOTAL FROM STD_INFO WHERE TOTAL>=80 AND GROUPP='MEDICAL'", conn);
            conn.Open();
            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            dataGridView1.DataSource = dt;
            conn.Close();
        }
    }
}

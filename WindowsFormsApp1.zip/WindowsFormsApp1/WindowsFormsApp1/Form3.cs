﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp1
{
    public partial class Form3 : Form
    {
        string conn_str = @"Data Source = DESKTOP-926II82\SQLEXPRESS; Initial Catalog= std_info; Integrated Security = true";
        public Form3()
        {
            InitializeComponent();
        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {

        }

        private void Form3_Load(object sender, EventArgs e)
        {
            DataSelect(); 
        }

        public void DataSelect()
        {
            SqlConnection conn = new SqlConnection(conn_str);
            SqlCommand cmd = new SqlCommand("SELECT GR_NO, NAME, F_NAME,EMAIL,GROUPP, MATRIC_MARKS, ENTRY_TEST, TOTAL, PERCENTAGE FROM STD_INFO", conn);
            conn.Open();
            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            dataGridView1.DataSource = dt;
            conn.Close();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void search_TextChanged(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(conn_str);
            SqlCommand cmd = new SqlCommand("SELECT GR_NO, NAME, F_NAME,EMAIL,GROUPP, MATRIC_MARKS, ENTRY_TEST, TOTAL, PERCENTAGE FROM STD_INFO WHERE NAME='" + search.Text + "'", conn);
            conn.Open();
            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            dataGridView1.DataSource = dt;
            conn.Close();
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void total_TextChanged(object sender, EventArgs e)
        {
        }


        private void done_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(conn_str);
            int MATRIC = Convert.ToInt32(matric_marks.Text);
            int ENTRY = Convert.ToInt32(entry.Text);



            SqlCommand cmd = new SqlCommand("UPDATE STD_INFO SET MATRIC_MARKS='"+MATRIC+"', ENTRY_TEST = '"+ ENTRY+"', TOTAL = '"+total.Text+"', PERCENTAGE='"+ per.Text + "' WHERE NAME = '"+search.Text+ "'", conn);
            conn.Open();


            cmd.ExecuteNonQuery();
            MessageBox.Show("UPDATED");
            conn.Close();
        }

        private void CAL_Click(object sender, EventArgs e)
        {
            
            int num1, num2;
            num1 = Convert.ToInt32(matric_marks.Text);
            num2 = Convert.ToInt32(entry.Text);
            int sum = num1 + num2;  
            total.Text = sum.ToString();
            double percent = (sum / 1200) * 100;
            per.Text = percent.ToString();

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void matric_marks_TextChanged(object sender, EventArgs e)
        {

        }

        private void label13_Click(object sender, EventArgs e)
        {

        }
    }
}

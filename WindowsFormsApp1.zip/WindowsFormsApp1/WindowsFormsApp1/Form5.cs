﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp1
{
    public partial class Form5 : Form
    {
        string conn_str = @"Data Source = DESKTOP-926II82\SQLEXPRESS; Initial Catalog= std_info; Integrated Security = true";

        public Form5()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Form5_Load(object sender, EventArgs e)
        {
            DataSelect();
        }

        public void DataSelect()
        {
            SqlConnection conn = new SqlConnection(conn_str);
            SqlCommand cmd = new SqlCommand("SELECT GR_NO, NAME, F_NAME,EMAIL,GROUPP, TOTAL FROM STD_INFO WHERE TOTAL>=80 AND GROUPP='ENGINEERING'", conn);
            conn.Open();
            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            dataGridView1.DataSource = dt;
            conn.Close();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
